export const environment = {
  production: false,
  appUrl: 'http://localhost:4200/api/Consultants_Maven'
};
