import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConsultantsComponent } from './consultants/consultants.component';
import { ConsultantdetailComponent } from './consultantdetail/consultantdetail.component';

const routes: Routes = [
  { path: 'list',  component: ConsultantsComponent  },
  { path: 'search', component: ConsultantsComponent },
  { path: 'detail/:id', component: ConsultantdetailComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
