import { Consultant } from './classes';

export const CONSULTANTS: Consultant[] = [
  { id: 1, firstname: 'Valentine' },
  { id: 2, firstname: 'Valentina' }
];