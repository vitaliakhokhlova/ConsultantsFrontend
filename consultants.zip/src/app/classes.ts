export abstract class Resource {
    id: number
  }

export class Consultant extends Resource{      
        lastname?: string;
        firstname: string;
        title?: string;
        forces?: Array<Force>;
        birthday?: Date;
        expession?: string;
        author?: string;
        profile?: string;
        interests?: string;
        occupancy?: string;
        mobility?: string;
        formations?: Array<Formation>;
}

export class Force extends Resource{
    description: string
}

export class Formation extends Resource{
    diplome: string;
    institution: string;
    location: string;
    year: number;
}